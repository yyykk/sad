#ifndef __XJBYC_H__
#define __XJBYC_H__

#include "predict.h"
#include <vector>

void xjbyc(std::vector<vm> &foreVm, std::vector<vm_data> &data, std::vector<vm> &vmInfoVec, float day_s);

#endif